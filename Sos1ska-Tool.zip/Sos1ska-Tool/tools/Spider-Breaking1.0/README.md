# Spider-Breaking1.0

Android:
1. Скачиваем ---> https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Заходим
3. Вводим ---> apt upfate && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Cool-Hackers/Spider-Breaking1.0
6. cd Spider-Breaking1.0/Spider-Breaking/
7. bash install-And,ios.sh
8. python3 Spider-Breaking.py

IOS:
1. Скачиваем ---> https://apps.apple.com/us/app/ish-shell/id1436902243
2. Заходим в него
3. Вводим ---> apt upfate && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Cool-Hackers/Spider-Breaking1.0
6. cd Spider-Breaking1.0/Spider-Breaking/
7. bash install-And,ios.sh
8. python3 Spider-Breaking.py

Windows:
1. Скачиваем ---> https://www.python.org/downloads/
2. Заходим
3. Скачиваем файлы с https://github.com/Cool-Hackers/Spider-Breakin2.0 или с https://drive.google.com/drive/folders/1htw-cbPOfMe0wqrb1EYkDxdPI61Oc_Jd?usp=sharing
4. Открываем сначало файл install-Windows.py
5. Потом уже открываем Spider-Breaking.py
