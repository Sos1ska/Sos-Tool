#!/usr/bin/python3
import os, sys
try: 
        import requests
except ImportError:
        if os.sys.platform == "win32":
                os.system("cls")
        else:
                os.system("clear")
        print(f"У вас нету request, для его установки введите pip install request")
try:
        import urllib.request
except ImportError:
        if os.sys.platform == "win32":
                os.system("cls")
        else:
                os.system("clear")
        print(f"У вас нету urllib, для его установки введите pip install urllib3")
import random
from time import sleep
try:
        import json
except ImportError:
        if os.sys.platform == "win32":
                os.system("cls")
        else:
                os.system("clear")
        print(f"У вас нету json, для его установки введите pip install json")
try:
        import bs4
except ImportError:
        if os.sys.platform == "win32":
                os.system("cls")
        else:
                os.system("clear")
        print(f"У вас нету bs4, для его установки введите pip install bs4")
from bs4 import BeautifulSoup as BS

Red = '\033[91m'
Green = '\033[92m'
Blue = '\033[94m'
Cyan = '\033[96m'
White = '\033[97m'
Yellow = '\033[93m'
Magenta = '\033[95m'
Grey = '\033[90m'
Black = '\033[90m'
Default = '\033[99m'
Underline = '\033[4m'
end       = '\033[0m'

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20
if os.sys.platform == "win32":
        os.system("cls")
else:
        os.system("clear")
print(f"C"),sleep(0.5),print(f" O"),sleep(0.5),print(f"  O"),sleep(0.5),print(f"   L"),sleep(0.5),print(f"    -"),sleep(0.5),print(f"     H"),sleep(0.5),print(f"      A"),sleep(0.5),print(f"       C"),sleep(0.5),print(f"        K"),sleep(0.5),print(f"         E"),sleep(0.5),print(f"          R"),sleep(0.5),print(f"           S"),sleep(0.5)
sleep(2)
if os.sys.platform == "win32":
        os.system("cls")
else:
        os.system("clear")
def banner():
        print(Magenta +'''
            
                                                /~__________~\ 
                                                .------------. 
                                               (|COOL-HACKERS|)
                                                '------------' 
                                                \_~~~~~~~~~~_/
         
         ''')
banner()
print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com{end}")
print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers{end}")
print(f"\t\t\t")
print(f"\t\t\t{Red} ВНИМАНИЕ {end}{Yellow}Всё что вы введёте попадает в файл collector.txt {end}")
print(f"\t\t\t")
print(f"\t\t\t{Yellow} Через 10 секунд будет доступно {end}")
sleep(10)
if os.sys.platform == "win32":
        os.system("cls")
else:
        os.system("clear")

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

def ban():
    print(Red +'''
       ______            __      __  __           __
      / ____/___  ____  / /     / / / /___ ______/ /_____  __________
     / /   / __ \/ __ \/ /_____/ /_/ / __ `/ ___/ //_/ _ \/ ___/ ___/
    / /___/ /_/ / /_/ / /_____/ __  / /_/ / /__/ ,< /  __/ /  (__  )
    \____/\____/\____/_/     /_/ /_/\__,_/\___/_/|_|\___/_/  /____/'''+ end)
def ban_ip():
    print(Red +'''
       ______            __      __  __           __
      / ____/___  ____  / /     / / / /___ ______/ /_____  __________
     / /   / __ \/ __ \/ /_____/ /_/ / __ `/ ___/ //_/ _ \/ ___/ __/_____
    / /___/ /_/ / /_/ / /_____/ __  / /_/ / /__/ ,< /  __/ /  (__  )____/
    \____/\____/\____/_/     /_/ /_/\__,_/\___/_/|_|\___/_/  /____/
        ________
       /  _/ __ \
       / // /_/ /
     _/ // ____/
    /___/_/'''+ end)
def ban_num_car():
    print(Red +'''
       ______            __      __  __           __
      / ____/___  ____  / /     / / / /___ ______/ /_____  __________
     / /   / __ \/ __ \/ /_____/ /_/ / __ `/ ___/ //_/ _ \/ ___/ __/_____
    / /___/ /_/ / /_/ / /_____/ __  / /_/ / /__/ ,< /  __/ /  (__  )____/
    \____/\____/\____/_/     /_/ /_/\__,_/\___/_/|_|\___/_/  /____/
        _   __                      ______
       / | / /_  ______ ___        / ____/___ ______
      /  |/ / / / / __ `__ \______/ /   / __ `/ ___/
     / /|  / /_/ / / / / / /_____/ /___/ /_/ / /
    /_/ |_/\__,_/_/ /_/ /_/      \____/\__,_/_/'''+ end)
def ban_num():
    print(Red +'''
       ______            __      __  __           __
      / ____/___  ____  / /     / / / /___ ______/ /_____  __________
     / /   / __ \/ __ \/ /_____/ /_/ / __ `/ ___/ //_/ _ \/ ___/ __/_____
    / /___/ /_/ / /_/ / /_____/ __  / /_/ / /__/ ,< /  __/ /  (__  )____/
    \____/\____/\____/_/     /_/ /_/\__,_/\___/_/|_|\___/_/  /____/

        _   __                __
       / | / /_  ______ ___  / /_  ___  _____
      /  |/ / / / / __ `__ \/ __ \/ _ \/ ___/
     / /|  / /_/ / / / / / / /_/ /  __/ /
    /_/ |_/\__,_/_/ /_/ /_/_.___/\___/_/
'''+ end)
def ban_nick():
    print(Red +'''
       ______            __      __  __           __
      / ____/___  ____  / /     / / / /___ ______/ /_____  __________
     / /   / __ \/ __ \/ /_____/ /_/ / __ `/ ___/ //_/ _ \/ ___/ __/_____
    / /___/ /_/ / /_/ / /_____/ __  / /_/ / /__/ ,< /  __/ /  (__  )____/
    \____/\____/\____/_/     /_/ /_/\__,_/\___/_/|_|\___/_/  /____/

        _   ___      __
       / | / (_)____/ /__
      /  |/ / / ___/ //_/
     / /|  / / /__/ ,<
    /_/ |_/_/\___/_/|_|'''+ end)

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

def clear():
    if os.sys.platform == "win32":
        os.system("cls")
    else:
        os.system("clear")

while True:
    clear()
    ban()
    print(f"\t\t\t{Red}{Underline} Spider-Breaking {end}")
    print(f"\t{Yellow} Введите какая функция вам нужна (цифру):{end}")
    print("[1] break-num - Пробив номера телефона [3] break-nick - Поиск ника по сети [2] break-ip - Пробив IP-Адреса [4] break-num-car - Пробив авто по номеру [0] Выключить код")

    start_input = input(Green + ">>> " + end)
    if str(start_input) == "0":
        print(f"\t\t\t{Yellow} Начинается выключение{end}")
        sleep(4)
        clear()
        ban()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")
        print(f"\t\t\t{Green}Код выключен успешно!{end}")
        quit()
    if str(start_input) == "1":
        clear()
        ban_num()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com{end}")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers{end}")

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        number_input = input(Yellow + "Введите номер телефона: " + end)
        fileD = open('collector.txt', 'a', encoding='utf-8')
        fileD.write(f'Number: {str(number_input)}')
        fileD.close()
# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        getInfo = f"https://htmlweb.ru/geo/api.php?json&telcod={str(number_input)}"
        try:
                infoNumber = urllib.request.urlopen( getInfo )
        except:
                print(f"[!] - {Red}Номер введён не верно{end} - [!]")

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        infoNumber = json.load( infoNumber )

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        try:
                print(f"{Blue}Страна {end}{Green}>>> {end}", infoNumber["country"]["fullname"])
        except KeyError:
                print(f"{Blue}Cтрана {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Blue}Столица {end}{Green}>>> {end}", infoNumber["capital"]["name"])
        except KeyError:
                print(f"{Blue}Столица {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}", infoNumber["capital"]["latitude"])
        except KeyError:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}", infoNumber["capital"]["longitude"])
        except KeyError:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}+", infoNumber["capital"]["time_zone"])
        except KeyError:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Код номера {end}{Green}>>> {end}", infoNumber["country"]["country_code3"])
        except KeyError:
                print(f"{Magenta}Код номера {end}{Green}>>> {end}{Red}Не удалось опеределить{end}")
        try:
                print(f"{Magenta}MCC номера {end}{Green}>>> {end}", infoNumber["country"]["mcc"])
        except KeyError:
                print(f"{Magenta}MCC номера {end}{Green}>>> {end}{Red}Не удалось оперделить{end}")
        try:
                print(f"{Magenta}Регион {end}{Green}>>> {end}", infoNumber["region"]["name"])
        except KeyError:
                print(f"{Magenta}Регион {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Округ {end}{Green}>>> {end}", infoNumber["region"]["okrug"])
        except KeyError:
                print(f"{Yellow}Округ {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}", infoNumber["region"]["autocod"])
        except KeyError:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Город {end}{Green}>>> {end}", infoNumber["0"]["name"])
        except KeyError:
            print(f"{Yellow}Город {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
            print(f"{Magenta}Широта города {end}{Green}>>> {end}", infoNumber["0"]["latitude"])
        except KeyError:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}", infoNumber["0"]["longitude"])
        except KeyError:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Oper_id {end}{Green}>>> {end}", infoNumber["0"]["oper_id"])
        except KeyError:
                print(f"{Magenta}Oper_id {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Радиус номеров телефонов {end}{Green}>>> {end}", infoNumber["0"]["def"])
        except KeyError:
                print(f"{Yellow}Радиус номеров телефоно {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Рабочесть телефона {end}{Green}>>> {end}", infoNumber["0"]["mobile"])
        except KeyError:
                print(f"{Yellow}Рабочесть телефона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Оператор {end}{Green}>>> {end}", infoNumber["0"]["oper"])
        except KeyError:
                print(f"{Yellow}Оператор {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        print()
        print("Если по всем пораметрам стоит надпись [Не удалось определить] проверьте номер на правильность")
        print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        print()
        print(f"{Yellow}Проверьте эти ссылки: {end}")
        print(f"https://api.whatsapp.com/send?phone={str(number_input)}&text=You,%20are&20hacked%20by%20by%20the%20Cool-Hackers - Поиск номера в {Green}WhatsApp{end}") 
        print(f"https://facebook.com/login/identify/?ctx=recover&ars=royal_blue_bar - Поиск номера в {Blue}Facebook{end}")
        print(f"https://linkedin.com/checkpoint/rp/request-password-reset-submit - Поиск номера в Linkedin")
        print(f"https://viber://add?number={str(number_input)} - Поиск номера в {Magenta}Viber{end}")
        print(f"https://skype:{str(number_input)}?call - Звонок через {Blue}Skype{end}")
        print(f"tel:{str(number_input)} - Простой звонок")
        print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        print()
        print(f"{Yellow}Вставьте эту ссылку в браузер с поисковой системой Yandex: ")
        print(f"site:vk.com {str(number_input)}")
        print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        print()
        print(f"Предоставить ли вам доступ к сотовым вышкам?")
        print(f"Вам надо запомнить широту и долготу города!")
        print(f"{Green}y{end}/{Red}n{end}")
        start_tower_input = input(Green + ">>> " + end)
        if str(start_tower_input) == "y":
            clear()
            ban_num()
            print(f"\t{Default}Наш ВК --->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, {end}")
            latitude_tower_input = input(Yellow + "Введите широту: " + end)
            longitude_tower_input = input(Yellow + "Введите долготу: " + end)
                    

            print(f"{Yellow}Вставьте данную ссылку в любой браузер: {end}")
            print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
            print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

            print()
            print(f"{Green}y{end}/{Red}n{end}")
            cont_input = input("Выключить код?")
            if str(cont_input) == "y":
                print(f"Выключаю код")
                sleep(2)
                clear()
                ban()
                print(f"\t\t\t{Red}{Underline} Cool-Breaking  {end}")
                print(f"\t\t\t{Yellow}{Underline} Наш ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
                print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
                print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")
                quit()
    if str(start_input) == "2":
        clear()
        ban_ip()
        print(f"\t\t\t{Red}{Underline} Cool-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наш ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        print(f"{Yellow}Для продолжения введите {end}{Green}y{end}{Yellow}/{end}{Red}n{end}")
        start_input = input(Yellow + "Введите ответ: " + end)
        if str(start_input) == "n":
                print(f"Выключаюсь")
                sleep(3)
                clear()
                print(f"\t\t\tКод успешно выключен!")
                print(f"\t\t\tСоздатель кода --> {Blue}https://vk.com/nikitasos1ska{end}")
                print(f"\t{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
                print(f"\t{Magenta}Наша почта {Green}--->{end} {Blue}soshack01@gmail.com{end}")
                quit()
        if str(start_input) == "y":
                print(f"\t\t\t{Yellow}Начинаю запуск кода{end} {Red}|{end} ")
                sleep(0.5)
                clear()
                print(f"\t\t\t{Yellow}Начинаю запуск кода{end} {Red}/{end} ")
                sleep(0.5)
                clear()
                print(f"\t\t\t{Yellow}Начинаю запуск кода{end} {Red}-{end}")
                sleep(0.5)
                clear()
                print(f"\t\t\t{Yellow}Начинаю запуск кода{end} {Red}\{end}")
                sleep(0.5)
                clear()
                print(f"\t\t\t{Yellow}Начинаю запуск кода{end} {Red}|{end}")
                sleep(0.5)
                clear()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        ban_ip()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")
        ip_input = input(Yellow + "Введите IP-адрес: " + end)
        fileD = open('collector.txt', 'a', encoding='utf-8')
        fileD.write(f'IP: {str(ip_input)}')
        fileD.close()
# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        getInfo = f"https://htmlweb.ru/geo/api.php?json&ip={str(ip_input)}"
        try:
                infoIP = urllib.request.urlopen( getInfo )
        except:
                print(f"[!] - {Red}IP-адрес введен не верно{end} - [!]")

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        infoIP = json.load( infoIP )

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

        try:
                print(f"{Blue}Страна {end}{Green}>>> {end}", infoIP["country"]["fullname"])
        except KeyError:
                print(f"{Blue}Cтрана {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Blue}Столица {end}{Green}>>> {end}", infoIP["id"]["name"])
        except KeyError:
                print(f"{Blue}Столица {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}", infoIP["id"]["latitude"])
        except KeyError:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}", infoIP["id"]["longitude"])
        except KeyError:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}+", infoIP["id"]["time_zone"])
        except KeyError:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Регион {end}{Green}>>> {end}", infoIP["region"]["name"])
        except KeyError:
                print(f"{Magenta}Регион {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Округ {end}{Green}>>> {end}", infoIP["region"]["okrug"])
        except KeyError:
                print(f"{Yellow}Округ {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}", infoIP["region"]["autocod"])
        except KeyError:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Город {end}{Green}>>> {end}", infoIP["region"]["city"])
        except KeyError:
                print(f"{Yellow}Город {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}", infoIP["latitude"])
        except KeyError:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}", infoIP["longitude"])
        except KeyError:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        print()
        print("Если по всем пораметрам стоит надпись [Не удалось определить] проверьте IP на правильность")
        print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20


        print()
        print(f"Предоставить ли вам доступ к сотовым вышкам?")
        print(f"Вам надо запомнить широту и долготу города!")
        print(f"{Green}y{end}/{Red}n{end}")
        start_tower_input = input(Green + ">>> " + end)
        if str(start_tower_input) == "y":
                clear()
                print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
                print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
                print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
                print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")
                latitude_tower_input = input(Yellow + "Введите широту: " + end)
                longitude_tower_input = input(Yellow + "Введите долготу: " + end)
                        

                print(f"{Yellow}Вставьте данную ссылку в любой браузер: {end}")
                print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
        print()

# Код написан ими: https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20

    if str(start_input) == "3":
        clear()
        ban_nick()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers")
        nick_input = input(Yellow + "Введите ник: " + end)
        fileD = open('collector.txt', 'a', encoding='utf-8')
        fileD.write(f'Nick: {str(nick_input)}')
        fileD.close()
        print(f"{Yellow}Какое кол-во профилей показать? (1-40)")
        nick_cont_input = input(Green + ">>> " + end)
        if str(nick_cont_input) == "1":
                print(f"https://vk.com/{str(nick_input)}")
        if str(nick_cont_input) == "2":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
        if str(nick_cont_input) == "3":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
        if str(nick_cont_input) == "4":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
        if str(nick_cont_input) == "5":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
        if str(nick_cont_input) == "6":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
        if str(nick_cont_input) == "7":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
        if str(nick_cont_input) == "8":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
        if str(nick_cont_input) == "9":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
        if str(nick_cont_input) == "10":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
        if str(nick_cont_input) == "11":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
        if str(nick_cont_input) == "12":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
        if str(nick_cont_input) == "13":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
        if str(nick_cont_input) == "14":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
        if str(nick_cont_input) == "15":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
        if str(nick_cont_input) == "16":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
        if str(nick_cont_input) == "17":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
        if str(nick_cont_input) == "18":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
        if str(nick_cont_input) == "19":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
        if str(nick_cont_input) == "20":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
        if str(nick_cont_input) == "21":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
        if str(nick_cont_input) == "22":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
        if str(nick_cont_input) == "23":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
        if str(nick_cont_input) == "24":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
        if str(nick_cont_input) == "25":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
        if str(nick_cont_input) == "26":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
        if str(nick_cont_input) == "27":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
        if str(nick_cont_input) == "28":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
        if str(nick_cont_input) == "29":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
        if str(nick_cont_input) == "30":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
        if str(nick_cont_input) == "31":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
        if str(nick_cont_input) == "32":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
        if str(nick_cont_input) =="33":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
        if str(nick_cont_input) == "34":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
        if str(nick_cont_input) == "35":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
        if str(nick_cont_input) == "36":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
                print(f"https://spletnik.ru/user/{str(nick_input)}")
        if str(nick_cont_input) == "37":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
                print(f"https://spletnik.ru/user/{str(nick_input)}")
        if str(nick_cont_input) == "38":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
                print(f"https://spletnik.ru/user/{str(nick_input)}")
                print(f"https://www.facebook.com/{str(nick_input)}")
        if str(nick_cont_input) == "39":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
                print(f"https://spletnik.ru/user/{str(nick_input)}")
                print(f"https://www.facebook.com/{str(nick_input)}")
                print(f"https://zen.yandex.ru/{str(nick_input)}")
        if str(nick_cont_input) == "40":
                print(f"https://vk.com/{str(nick_input)}")
                print(f"https://my.mail.ru/mail/{str(nick_input)}")
                print(f"https://www.drive2.ru/users/{str(nick_input)}")
                print(f"https://twitter.com/{str(nick_input)}")
                print(f"https://github.com/{str(nick_input)}")
                print(f"https://instagram.com/{str(nick_input)}")
                print(f"http://forum.3dnews.ru/member.php?username={str(nick_input)}")
                print(f"https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username={str(nick_input)}")
                print(f"https://forums.adobe.com/profile/{str(nick_input)}")
                print(f"https://ask.fm/{str(nick_input)}")
                print(f"https://badoo.com/profile/{str(nick_input)}")
                print(f"https://www.bandcamp.com/{str(nick_input)}")
                print(f"https://bitcoinforum.com/profile/{str(nick_input)}")
                print(f"https://dev.to/{str(nick_input)}")
                print(f"https://www.ebay.com/usr/{str(nick_input)}")
                print(f"https://www.gamespot.com/profile/{str(nick_input)}")
                print(f"https://ok.ru/{str(nick_input)}")
                print(f"https://play.google.com/store/apps/developer?id={str(nick_input)}")
                print(f"https://pokemonshowdown.com/users/{str(nick_input)}")
                print(f"https://www.reddit.com/user/{str(nick_input)}")
                print(f"https://steamcommunity.com/id/{str(nick_input)}")
                print(f"https://steamcommunity.com/groups/{str(nick_input)}")
                print(f"https://tamtam.chat/{str(nick_input)}")
                print(f"https://t.me/{str(nick_input)}")
                print(f"https://www.tiktok.com/@{str(nick_input)}")
                print(f"https://www.twitch.tv/{str(nick_input)}")
                print(f"https://data.typeracer.com/pit/profile?user={str(nick_input)}")
                print(f"https://www.wikipedia.org/wiki/User:{str(nick_input)}")
                print(f"https://yandex.ru/collections/user/{str(nick_input)}")
                print(f"https://www.youtube.com/{str(nick_input)}")
                print(f"https://www.baby.ru/u/{str(nick_input)}")
                print(f"https://www.babyblog.ru/user/info/{str(nick_input)}")
                print(f"https://www.geocaching.com/profile/?u={str(nick_input)}")
                print(f"https://habr.com/ru/users/{str(nick_input)}")
                print(f"https://pikabu.ru/@{str(nick_input)}")
                print(f"https://spletnik.ru/user/{str(nick_input)}")
                print(f"https://www.facebook.com/{str(nick_input)}")
                print(f"https://zen.yandex.ru/{str(nick_input)}")
                print(f"https://ggscore.com/ru/dota-2/player?t={str(nick_input)}")
                print(f"https://www.facebook.com/public/{str(nick_input)}")
        print(f"Продолжить? {Green}y{end}/{Red}n{end}")
        cont_2_input = input(Green + ">>> " + end)
        if str(cont_2_input) == "n":
                print(f"Начинаю вылючатся")
                sleep(1)
                clear()
                banner()
                ban()
                print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
                print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
                print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
                print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers{end}")
                print(f"\t\t\t{Green}Код успешно выключен !{end}")
                quit()
    if str(start_input) == "4":
        clear()
        ban_num_car()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers{end}")
        num_car_input = input(Yellow + "Введите номер авто как на примере (А11АА77): " + end)
        fileD = open('collector.txt', 'a', encoding='utf-8')
        fileD.write(f'Number-Car: {str(num_car_input)}')
        fileD.close()
        clear()
        print(f"\t\t\t{Yellow} Начинаю поиск информации {end}{Red}|{end}")
        sleep(0.5)
        clear()
        print(f"\t\t\t{Yellow} Начинаю поиск информации {end}{Red}/{end}")
        sleep(0.5)
        clear()
        print(f"\t\t\t{Yellow} Начинаю поиск информации {end}{Red}-{end}")
        sleep(0.5)
        clear()  
        print(f"\t\t\t{Yellow} Начинаю поиск информации {end}{Red}\{end}")
        sleep(0.5)
        clear()
        print(f"\t\t\t{Yellow} Начинаю поиск информации {end}{Red}|{end}")
        sleep(0.5)
        clear()
        ban_num_car()
        print(f"\t\t\t{Red}{Underline} Spider-Breaking  {end}")
        print(f"\t\t\t{Yellow}{Underline} Наши профили ВК {end}{Green}--->{end}{Blue} https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/covidone, https://vk.com/paket20{end}")
        print(f"\t\t\t{Yellow}{Underline} Наша почта {end}{Green}--->{end}{Blue} soshack00@gmail.com")
        print(f"\t\t\t{Yellow}{Underline} Наши GitHub профили {end}{Green}--->{end}{Blue} https://github.com/Sos1ska, https://github.com/Ki11sesh, https://github.com/Cool-Hackers{end}")
        print()
        print(f"\t https://авто-история.рф/num/{str(num_car_input)}/")
        print(f"\t https://www.230km.ru/{str(num_car_input)}.nomer")
        print(f"\t http://avto-nomer.ru/ru/gallery.php?fastsearch={str(num_car_input)}")