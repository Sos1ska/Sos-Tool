

pkg insatll python -y
pip install --upgrade pip
pip install request
pip install bs4
pip install urllib3
pip install json
clear

echo -e "                        python3 Spider-Breaking.py"