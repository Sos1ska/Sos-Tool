# Sms-BombRu2.0

TERMUX:
1. Скачиваем https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Заходим
3. Вводим apt update && apt upgrade
4. Вводим pkg install git
5. Вводим git clone https://github.com/Sos1ska/Sms-BombRu2.0
6. Потом sh ~/Sms-BombRu2.0/Sms-BombRu2.0/Unix/install.sh
7. cd Sms-BombRu2.0/Sms-BombRu2.0/Unix/ 
8. python3 Sms-BomberSos2.1.py

IOS:
1. Скачиваем https://apps.apple.com/ru/app/testflight/id899247664 потом начать тестирование в https://testflight.apple.com/join/97i7KM8O
2. apk update
3. apk upgrade
4. apk add git
5. git clone https://github.com/Sos1ska/Sms-BombRu2.0
6. sh ~/Sms-BombRu2.0/Sms-BombRu2.0/Unix/install.sh
7. cd Sms-BombRu2.0/Sms-BombRu2.0/Unix/
8. python3 Sms-BomberSos2.1.py

WINDOWS:
1. Скачиваем 
2. Выбираем диск который нам надо
3. Запускаем файл
