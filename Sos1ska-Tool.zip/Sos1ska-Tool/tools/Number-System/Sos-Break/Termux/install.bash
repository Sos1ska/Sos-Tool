

clear
pkg install python -y
clear
pkg install toilet -y
clear
pkg install cowsay -y
clear
pkg install figlet -y
clear
pkg install nano -y
clear
pkg install lolcat
clear
echo
echo -e "           python3 Breaking2.0.py"
echo