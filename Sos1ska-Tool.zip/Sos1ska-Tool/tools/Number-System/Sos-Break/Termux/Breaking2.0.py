import os
import json
import urllib.request
import time

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

Red = '\033[91m'
Green = '\033[92m'
Blue = '\033[94m'
Cyan = '\033[96m'
White = '\033[97m'
Yellow = '\033[93m'
Magenta = '\033[95m'
Grey = '\033[90m'
Black = '\033[90m'
Default = '\033[99m'
Underline = '\033[4m'
end       = '\033[0m'

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

os.system("clear")
print(f"C"),time.sleep(1),print(f" O"),time.sleep(1),print(f"  O"),time.sleep(1),print(f"   L"),time.sleep(1),print(f"    -"),time.sleep(1),print(f"     H"),time.sleep(1),print(f"      A"),time.sleep(1),print(f"       C"),time.sleep(1),print(f"        K"),time.sleep(1),print(f"         E"),time.sleep(1),print(f"          R"),time.sleep(1),print(f"           S")
print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
print()
print(f"\tДанный установщик появиться только при запуске утилиты")
print(f"\tДанный код написан для базы Android")
print()

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

print(f"Произвести проверку нужных комопнентов? {Green}y{end}/{Red}n{end}")
install_input = input(Green + ">>> " + end)
if str(install_input) == "y":
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов | ")
        time.sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов / ")
        time.sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов \ ")
        time.sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов | ")
        time.sleep(1)
        os.system("clear")
        os.system("apt update -y")
        os.system("apt upgrade -y")
        os.system("clear")
        mod = ("urllib3", "request")
        for i in range(len(mod)):
                os.system("pip install "+mod[i])
                os.system("clear")
        mod = ("figlet", "toilet", "cowsay", "nano", "rudy")
        for i in range(len(mod)):
                os.system("pkg install "+mod[i]+"-y")
                os.system("clear")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        os.system("gem install lolcat")
        os.system("clear")
        print(f"\t\t\t{Green}Проверка нужных компонентов пройдена!{end}")
        time.sleep(3)
        os.system("clear")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

while True:
        os.system("clear")
        print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
        os.system("toilet -f big ' Cool-Hackers' -F gay | lolcat")
        print(f"\t{Default}Наш ВК --->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, {end}")
        print(f"\t{Default}Наша почта --->{end} {Blue}soshack01@gmail.com{end}")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print(f"{Default}Код написан ими --->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, {end}")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print(f"{Yellow}Для продолжения введите {end}{Green}y{end}{Yellow}/{end}{Red}n{end}")
        start_input = input(Yellow + "Введите ответ: " + end)
        if str(start_input) == "n":
                print(f"Выключаюсь")
                time.sleep(3)
                os.system("clear")
                print(f"\t\t\tКод успешно выключен!")
                print(f"\t\t\tСоздатели кода --> {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, ")
                quit()
        if str(start_input) == "y":
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}|{end} ")
                time.sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}/{end} ")
                time.sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}\{end}")
                time.sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}|{end}")
                time.sleep(2)
                os.system("clear")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
        os.system("toilet -f big ' Cool-Hackers' -F gay | lolcat")
        print(f"\t{Default}Наш ВК --->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, {end}")
        number_input = input(Yellow + "Введите номер телефона: " + end)

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        getInfo = f"https://htmlweb.ru/geo/api.php?json&telcod={str(number_input)}"
        try:
                infoNumber = urllib.request.urlopen( getInfo )
        except:
                print(f"[!] - {Red}Номер введён не верно{end} - [!]")

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        infoNumber = json.load( infoNumber )

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        try:
                print(f"{Blue}Страна {end}{Green}>>> {end}", infoNumber["country"]["fullname"])
        except KeyError:
                print(f"{Blue}Cтрана {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Blue}Столица {end}{Green}>>> {end}", infoNumber["capital"]["name"])
        except KeyError:
                print(f"{Blue}Столица {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}", infoNumber["capital"]["latitude"])
        except KeyError:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}", infoNumber["capital"]["longitude"])
        except KeyError:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}+", infoNumber["capital"]["time_zone"])
        except KeyError:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Код номера {end}{Green}>>> {end}", infoNumber["country"]["country_code3"])
        except KeyError:
                print(f"{Magenta}Код номера {end}{Green}>>> {end}{Red}Не удалось опеределить{end}")
        try:
                print(f"{Magenta}MCC номера {end}{Green}>>> {end}", infoNumber["country"]["mcc"])
        except KeyError:
                print(f"{Magenta}MCC номера {end}{Green}>>> {end}{Red}Не удалось оперделить{end}")
        try:
                print(f"{Magenta}Регион {end}{Green}>>> {end}", infoNumber["region"]["name"])
        except KeyError:
                print(f"{Magenta}Регион {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Округ {end}{Green}>>> {end}", infoNumber["region"]["okrug"])
        except KeyError:
                print(f"{Yellow}Округ {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}", infoNumber["region"]["autocod"])
        except KeyError:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Город {end}{Green}>>> {end}", infoNumber["0"]["name"])
        except KeyError:
                print(f"{Yellow}Город {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}", infoNumber["0"]["latitude"])
        except KeyError:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}", infoNumber["0"]["longitude"])
        except KeyError:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Oper_id {end}{Green}>>> {end}", infoNumber["0"]["oper_id"])
        except KeyError:
                print(f"{Magenta}Oper_id {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Радиус номеров телефонов {end}{Green}>>> {end}", infoNumber["0"]["def"])
        except KeyError:
                print(f"{Yellow}Радиус номеров телефоно {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Рабочесть телефона {end}{Green}>>> {end}", infoNumber["0"]["mobile"])
        except KeyError:
                print(f"{Yellow}Рабочесть телефона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Оператор {end}{Green}>>> {end}", infoNumber["0"]["oper"])
        except KeyError:
                print(f"{Yellow}Оператор {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        print()
        print("Если по всем пораметрам стоит надпись [Не удалось определить] проверьте номер на правильность")
        print()

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print()
        print(f"{Yellow}Проверьте эти ссылки: ")
        print(f"https://api.whatsapp.com/send?phone={str(number_input)}&text=You,%20are&20hacked%20by%20by%20the%20Cool-Hackers - Поиск номера в WhatsApp") 
        print(f"https://facebook.com/login/identify/?ctx=recover&ars=royal_blue_bar - Поиск номера в Facebook")
        print(f"https://linkedin.com/checkpoint/rp/request-password-reset-submit - Поиск номера в Linkedin")
        print(f"https://viber://add?number={str(number_input)} - Поиск номера в Viber")
        print(f"https://skype:{str(number_input)}?call - Звонок через Skype")
        print(f"tel:{str(number_input)} - Простой звонок")
        print()

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print()
        print(f"{Yellow}Вставьте эту ссылку в браузер с поисковой системой Yandex: ")
        print(f"site:vk.com {str(number_input)}")
        print()

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print()
        print(f"Предоставить ли вам доступ к сотовым вышкам?")
        print(f"Вам надо запомнить широту и долготу города!")
        print(f"{Green}y{end}/{Red}n{end}")
        start_tower_input = input(Green + ">>> " + end)
        if str(start_tower_input) == "y":
                os.system("clear")
                print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
                os.system("toilet -f big ' Cool-Haackers' -F gay | lolcat")
                print(f"\t{Default}Наш ВК --->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, {end}")
                latitude_tower_input = input(Yellow + "Введите широту: " + end)
                longitude_tower_input = input(Yellow + "Введите долготу: " + end)
                        

                print(f"{Yellow}Вставьте данную ссылку в любой браузер: {end}")
                print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
        print()

# Код писали https://vk.com/covidone
#            https://vk.com/nikitasos1ska
#            https://vk.com/2pac_jdm
#            https://vk.com/paket20

        print()
        print(f"{Green}y{end}/{Red}n{end}")
        cont_input = input("Выключить утилиту?")
        if str(cont_input) == "y":
                print(f"Выключаю утилиту")
                time.sleep(2)
                os.system("clear")
                print(f"Над данным кодом работали ---> {Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, ")
                quit()