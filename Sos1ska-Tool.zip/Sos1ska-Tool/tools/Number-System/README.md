# Number-System
Данная утилита пробивает номер телефона жертвы

Termux:
1. Скачиваем файл https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Зхаодим в него
3. pkg install git -y 
4. git clone https://github.com/Sos1ska/Number-System
5. cd Number-System/Sos-Break/Termux/
6. bash install.sh
7. python3 Breaking2.0.py

Windows:
1. Скачиваем Python https://www.python.org/downloads/
2. Перейти по папке где загружена данная утилита
3. Запустить код просто открыв файл

IOS:
1. Скачиваем файл https://apps.apple.com/us/app/ish-shell/id1436902243
2. Заходим в него
3. Вводим команду pkg install git -y
4. git clone https://github.com/Sos1ska/Number-System
5. cd Number-System/Sos-Break/Termux/
6. bash install.sh
7. python3 Breaking2.0.py
