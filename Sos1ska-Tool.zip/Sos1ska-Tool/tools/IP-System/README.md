# IP-System
Termux Android RU
1. Скачиваем файл --> https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Заходим в него
3. Вводим apt update && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Sos1ska/IP-System
6. cd IP-System/Sos-BreakingIP/Termux/
7. bash install.sh
8. python3 BreakIP.py

IOS RU
1. Скачиваем файл --> https://apps.apple.com/us/app/ish-shell/id1436902243
2. Заходим в него
3. Вводим apt update && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Sos1ska/IP-System
6. cd IP-System/Sos-BreakingIP/Termux/
7. bash install.sh
8. python3 BreakIP.py

Windows RU
1. Скачиваем Python --> https://www.python.org/downloads/
2. Скачиваем файл с Git
3. Заходим в install.py
4. Заходим в BreakIP.py

Termux EN
1. Download the file --> https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. We go into it
3. Introduce apt update && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Sos1ska/IP-System
6. cd IP-System/Sos-BreakingIP/Termux/
7. bash install.sh
8. python3 BreakIP.py

IOS EN
1. Download the file --> https://apps.apple.com/us/app/ish-shell/id1436902243
2. We go into it
3. Introduce apt update && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Sos1ska/IP-System
6. cd IP-System/Sos-BreakingIP/Termux/
7. bash install.sh
8. python3 BreakIP.py

Windows EN
1. Download the file --> https://www.python.org/downloads/
2. Download the file from Git 
3. Go to intsall.py
4. Go to BreakIP.py
