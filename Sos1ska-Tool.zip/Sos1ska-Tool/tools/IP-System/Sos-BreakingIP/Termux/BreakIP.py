import os
import json
import urllib.request
from time import sleep

# Код писал https://vk.com/nikitasos1ska

Red = '\033[91m'
Green = '\033[92m'
Blue = '\033[94m'
Cyan = '\033[96m'
White = '\033[97m'
Yellow = '\033[93m'
Magenta = '\033[95m'
Grey = '\033[90m'
Black = '\033[90m'
Default = '\033[99m'
Underline = '\033[4m'
end       = '\033[0m'

# Код писал https://vk.com/nikitasos1ska

os.system("clear")
print(f"C"),sleep(0.5),print(f" O"),sleep(0.5),print(f"  O"),sleep(0.5),print(f"   L"),sleep(0.5),print(f"    -"),sleep(0.5),print(f"     H"),sleep(0.5),print(f"      A"),sleep(0.5),print(f"       C"),sleep(0.5),print(f"        K"),sleep(0.5),print(f"         E"),sleep(0.5),print(f"          R"),sleep(0.5),print(f"           S"),sleep(0.5)
print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
print(f"{Magenta}Над данным кодом работал {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska")
print(f"{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
print(f"{Magenta}Наша почта {end}{Green}--->{end} {Blue}soshack00@gmail.com{end}")
print()
print(f"\tДанный установщик появиться только при запуске утилиты")
print(f"\tДанный код написан для базы Android")
print()

# Код писал https://vk.com/nikitasos1ska

print(f"Произвести проверку нужных комопнентов? {Green}y{end}/{Red}n{end}")
install_input = input(Green + ">>> " + end)
if str(install_input) == "y":
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов | ")
        sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов / ")
        sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов \ ")
        sleep(1)
        os.system("clear")
        print(f"\t\t\tНачинаю проверку нужных компонентов | ")
        sleep(1)
        os.system("clear")
        os.system("apt update -y")
        os.system("apt upgrade -y")
        os.system("clear")
        mod = ("urllib3", "request")
        for i in range(len(mod)):
                os.system("pip install "+mod[i])
                os.system("clear")
        mod = ("figlet", "toilet", "cowsay", "nano", "rudy")
        for i in range(len(mod)):
                os.system("pkg install "+mod[i]+"-y")
                os.system("clear")

# Код писал http://vk.com/nikitasos1ska

        os.system("gem install lolcat")
        os.system("clear")
        print(f"\t\t\t{Green}Проверка нужных компонентов пройдена!{end}")
        sleep(3)
        os.system("clear")

# Код писал https://vk.com/nikitasos1ska

while True:
        os.system("clear")
        print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
        os.system("toilet -f big ' Cool-Hackers' -F gay | lolcat")
        print(f"\t{Magenta}Код написан им {Green}--->{end} {Blue}https://vk.com/nikitasos1ska{end}")
        print(f"\t{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
        print(f"\t{Magenta}Наша почта {Green}--->{end} {Blue}soshack01@gmail.com{end}")

# Код писал https://vk.com/nikitasos1ska

# Код писал https://vk.com/nikitasos1ska

        print(f"{Yellow}Для продолжения введите {end}{Green}y{end}{Yellow}/{end}{Red}n{end}")
        start_input = input(Yellow + "Введите ответ: " + end)
        if str(start_input) == "n":
                print(f"Выключаюсь")
                sleep(3)
                os.system("clear")
                print(f"\t\t\tКод успешно выключен!")
                print(f"\t\t\tСоздатель кода --> {Blue}https://vk.com/nikitasos1ska{end}")
                print(f"\t{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
                print(f"\t{Magenta}Наша почта {Green}--->{end} {Blue}soshack01@gmail.com{end}")
                quit()
        if str(start_input) == "y":
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}|{end} ")
                sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}/{end} ")
                sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}\{end}")
                sleep(2)
                os.system("clear")
                print(f"\t\t\t{Yellow}Начинаю запуск утилиты{end} {Red}|{end}")
                sleep(2)
                os.system("clear")

# Код писал https://vk.com/nikitasos1ska

        print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
        os.system("toilet -f big ' Cool-Hackers' -F gay | lolcat")
        print(f"\t{Magenta}Код написан им {Green}--->{end} {Blue}https://vk.com/nikitasos1ska{end}")
        print(f"\t{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
        print(f"\t{Magenta}Наша почта {Green}--->{end} {Blue}soshack01@gmail.com{end}")
        ip_input = input(Yellow + "Введите IP-адрес: " + end)

# Код писал https://vk.com/nikitasos1ska

        getInfo = f"https://htmlweb.ru/geo/api.php?json&ip={str(ip_input)}"
        try:
                infoIP = urllib.request.urlopen( getInfo )
        except:
                print(f"[!] - {Red}IP-адрес введен не верно{end} - [!]")

# Код писал https://vk.com/nikitasos1ska

        infoIP = json.load( infoIP )

# Код писал ://vk.com/nikitasos1ska

        try:
                print(f"{Blue}Страна {end}{Green}>>> {end}", infoIP["country"]["fullname"])
        except KeyError:
                print(f"{Blue}Cтрана {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Blue}Столица {end}{Green}>>> {end}", infoIP["id"]["name"])
        except KeyError:
                print(f"{Blue}Столица {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}", infoIP["id"]["latitude"])
        except KeyError:
                print(f"{Yellow}Широта столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}", infoIP["id"]["longitude"])
        except KeyError:
                print(f"{Yellow}Долгота столицы {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}+", infoIP["id"]["_zone"])
        except KeyError:
                print(f"{Yellow}Тип времени {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Регион {end}{Green}>>> {end}", infoIP["region"]["name"])
        except KeyError:
                print(f"{Magenta}Регион {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Округ {end}{Green}>>> {end}", infoIP["region"]["okrug"])
        except KeyError:
                print(f"{Yellow}Округ {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}", infoIP["region"]["autocod"])
        except KeyError:
                print(f"{Yellow}Код региона {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Yellow}Город {end}{Green}>>> {end}", infoIP["region"]["city"])
        except KeyError:
                print(f"{Yellow}Город {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}", infoIP["latitude"])
        except KeyError:
                print(f"{Magenta}Широта города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        try:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}", infoIP["longitude"])
        except KeyError:
                print(f"{Magenta}Долгота города {end}{Green}>>> {end}{Red}Не удалось определить{end}")
        print()
        print("Если по всем пораметрам стоит надпись [Не удалось определить] проверьте IP на правильность")
        print()

# Код писал https://vk.com/nikitasos1ska

# Код писал https://vk.com/nikitasos1ska

# Код писал https://vk.com/nikitasos1ska


        print()
        print(f"Предоставить ли вам доступ к сотовым вышкам?")
        print(f"Вам надо запомнить широту и долготу города!")
        print(f"{Green}y{end}/{Red}n{end}")
        start_tower_input = input(Green + ">>> " + end)
        if str(start_tower_input) == "y":
                os.system("clear")
                print(f"\t\t\t{Red}{Underline}Sos-Breaking-Number 2.0{end}")
                os.system("toilet -f big ' Cool-Haackers' -F gay | lolcat")
                print(f"\t{Magenta}Код написан им {Green}--->{end} {Blue}https://vk.com/nikitasos1ska{end}")
                print(f"\t{Magenta}Наш ВК {end}{Green}--->{end} {Blue}https://vk.com/nikitasos1ska, https://vk.com/covidone, https://vk.com/2pac_jdm, https://vk.com/paket20{end}")
                print(f"\t{Magenta}Наша почта {Green}--->{end} {Blue}soshack01@gmail.com{end}")
                latitude_tower_input = input(Yellow + "Введите широту: " + end)
                longitude_tower_input = input(Yellow + "Введите долготу: " + end)
                        

                print(f"{Yellow}Вставьте данную ссылку в любой браузер: {end}")
                print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
        print()

# Код писал https://vk.com/nikitasos1ska

        print()
        print(f"{Green}y{end}/{Red}n{end}")
        cont_input = input("Выключить утилиту?")
        if str(cont_input) == "y":
                print(f"Выключаю утилиту")
                sleep(2)
                os.system("clear")
                print(f"Над данным кодом работал ---> {Blue}https://vk.com/nikitasos1ska {end}")
                print(f"{Magenta}Наш ВК {Green}---> {end}{Blue}https://vk.com/nikitasos1ska, https://vk.com/2pac_jdm, https://vk.com/paket20, https://vk.com/covidone")
                print(f"Ссылка на наш Github {Green}---> {end}https://github.com/Sos1ska, https://github.com/Cooll-Hackers, https://github.com/Ki11sesh")
                quit()