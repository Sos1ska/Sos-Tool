

clear
apt update
apt upgrade
pkg install python -y
pkg install figlet -y
pkg install toilet -y
pkg install cowsay -y
pkg install nano -y
pkg install rudy -y
pkg install lolcat
echo
echo -e "Python3 BreakIP.py"
echo