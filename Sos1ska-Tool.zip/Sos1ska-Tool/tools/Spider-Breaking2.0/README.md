# Spider-Breaking2.0

Android:
1. Скачиваем ---> https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Заходим
3. Вводим ---> apt upfate && apt upgrade
4. pkg install git -y
5. git clone https://github.com/Cool-Hackers/Spider-Breaking
6. sh ~/Spider-Breaking/Spider-Breaking2.0/Unix/install.sh
7. spider

IOS:
1. Скачать ---> https://apps.apple.com/ru/app/testflight/id899247664 потом начать тестирование в ---> https://testflight.apple.com/join/97i7KM8O
2. apk update
3. apk upgrade
4. apk add git
5. git clone https://github.com/Cool-Hackers/Spider-Breaking2.0
6. sh ~/Spider-Breaking/Spider-Breaking2.0/Unix/install.sh
7. spider

Windows:
1. Скачиваем папку
2. Просто заходим в Spider-Breaking.exe 
3. Радуемся
