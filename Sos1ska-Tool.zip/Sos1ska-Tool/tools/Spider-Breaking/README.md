# Spider-Breaking3.0

Android:
1. Скачиваем ---> https://play.google.com/store/apps/details?id=com.termux&hl=ru&gl=US
2. Заходим
3. Вводим ---> pkg install git -y
4. git clone https://github.com/Sos1ska/Spider-Breaking
5. chmod +x ~/Spider-Breaking/Breaking3.0/Unix/install.sh
6. sh ~/Spider-Breaking/Breaking3.0/Unix/install.sh

IOS:
1. Скачать ---> https://apps.apple.com/ru/app/testflight/id899247664 потом начать тестирование в ---> https://testflight.apple.com/join/97i7KM8O
2. apk update
3. apk upgrade
4. apk add git
5. git clone https://github.com/Sos1ska/Spider-Breaking
6. chmod +x ~/Spider-Breaking/Breaking3.0/Unix/install.sh
7. sh ~/Spider-Breaking/Breaking3.0/Unix/install.sh

Windows:
1. Скачиваем zip файл
2. Распаковываем zip файл
3. Преходим в папки Spider-Breaking/Breaking3.0/Windows/
4. И нажимаем setup.exe
