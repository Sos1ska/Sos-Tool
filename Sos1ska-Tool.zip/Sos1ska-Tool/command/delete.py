#!/usr/bin/python3
import os

print('Введите путь файла для его удаления')
print('Пример:'
'>>> ~/file'
'После этого ваш файл будет преместится в корзину под названием trash')
file = input('>>> ')
os.system(f'mv {str(file)} /data/data/com.termux/files/Sos1ska/trash')